﻿var log = function (val) {
    console.log(val);
}

var isContains = function(str, substr) {
    return str.indexOf(substr) >= 0;
}